package e.huws.vibration; //folder to which the source code belongs

import android.os.AsyncTask;
import android.os.SystemClock;
import android.os.Vibrator;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit; // imports necessary files


public class MainActivity extends AppCompatActivity { //AppCompatActivity is a class in Android which contains important
    //methods and functions

    FirebaseDatabase database; //initialising the firebase database
    DatabaseReference myRef; //giving the firebase database a reference
    DatabaseReference ledstatus1; //calling the reference 'ledstatus1'

    Button b1; //declaring a button that will open the door
    Vibrator vibrator; //declaring a vibrator called vibrator
    TextView textView1; //declaring a textview in order to display the value of ledstatus1
    TextView textView2; //declaring a textview in order to display whether someone is at the door or not

    @Override //public class overrides the following...
    protected void onCreate(Bundle savedInstanceState) { //creating the activity
        super.onCreate(savedInstanceState); //call upon the on create activity if it's overriden
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_main); //sets the User Interface as activity_main

        //getting the value of ledstatus1 from the database
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("ESP32_Test");
        ledstatus1 = myRef.child("ledstatus1");

        b1 = (Button) findViewById(R.id.blong);  //creating a button called b1 and linking it with the button from the design view
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE); //using Android vibration service to create a vibrator
        textView1 = (TextView)findViewById(R.id.textView1); //creating a textview and linking it with textview1 from the design view
        textView2 = (TextView)findViewById(R.id.textView2); //creating a textview and linking it with textview2 from the design view

        //listens out for any change in value of 'ledstatus1' and displays the current value reading in 'textview1'
        ledstatus1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue(String.class);
                Log.d("file", "Value is: " + value);
                textView1.setText(value);


                //if value = 1, then print to 'textview2' that the doorbell has been pressed. Also, vibrate the phone for 30 seconds
                if (value.equals("1")) {
                    textView2.setText("Doorbell has been pressed");
                    vibrator.vibrate(30000);
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            ledstatus1.setValue("2");
                        }
                    },30000);
                }

                //if value = 0 then print to 'textview2' that there are no current calls. Cancel the vibrator
                else if (value.equals("0")){
                    textView2.setText("No current calls");
                    vibrator.cancel();
                }

                else if (value.equals("2")){
                }

                //if value is none of the above, print to textview2 that there are network problems.
                else {
                    textView2.setText("Network problems");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Log.w("file","Failed to read value", databaseError.toException());
            }
        });

        //if b1 (open door) is pressed, switch ledstatus to "0" and therefore open the door
            b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            ledstatus1.setValue("0");
            }
        });
    }

}
